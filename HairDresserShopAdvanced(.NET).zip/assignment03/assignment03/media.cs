﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment03
{
    public abstract class media : ISearchable
    {
        public string Title { get; protected set; }          // Title of the media object
        public int Year { get; protected set; }
        public media(string title, int year)
        {
            Title = title;
            Year = year;
        }

        #region ISearchable

        /// <summary>
        /// All Media objects are searchable on their Title property.
        /// 
        /// For an individual Media object, this means that given a string as a
        /// search key, the Search() method will either locate that string in
        /// the Title property or it will not.
        /// 
        /// If not overridden, this method can be used by all derived classes 'as is'.
        /// </summary>
        /// <param name="key">The string to be searching for</param>
        /// <returns>A flag indicating whether the search string was found (true) or not (false)</returns>

        public bool Search(string key)
        {
            // Make the search case insensitive by treating strings as lowercase
            string temp = Title.ToLower();

            if (temp.IndexOf(key.ToLower()) >= 0)
                return true;                        // Found it
            else
                return false;                       // Didn't find it
        }

        #endregion  // End ISearchable
    }
}
