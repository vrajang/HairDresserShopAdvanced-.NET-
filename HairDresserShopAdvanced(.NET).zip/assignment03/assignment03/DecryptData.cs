﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment03
{
    class DecryptData : IEncryptable
    {
        public string Summary;

        public DecryptData(string Summary)
        {
            this.Summary = Summary;
        }
        public string Encrypt()
        {
            return "";
        }
        public string Decrypt()
        {

            char[] array = Summary.ToCharArray();
            for (int i = 0; i < array.Length; i++)
            {
                int number = (int)array[i];

                if (number >= 'a' && number <= 'z')
                {
                    if (number > 'm')
                    {
                        number -= 13;   //moves the number 13 spaces back
                    }
                    else
                    {
                        number += 13;   //moves the number 13 spaces forward
                    }
                }
                else if (number >= 'A' && number <= 'Z')
                {
                    if (number > 'M')
                    {
                        number -= 13; //moves the number 13 spaces back
                    }
                    else
                    {
                        number += 13;   //moves the number 13 spaces forward
                    }
                }
                array[i] = (char)number;    //sets the array to the new numbers for the new characters 
            }
            return new string(array);   //sending the decrypted data back

        }
        
    }
}
