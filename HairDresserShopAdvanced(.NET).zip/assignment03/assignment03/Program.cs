﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace assignment03
{
    class Program
    {
        private static int choice = 0;
        private static media[] myMediaList = new media[1000];
        private static Book[] myBook = new Book[1000];
        private static song[] mySong = new song[1000];
        private static movie[] myMovie = new movie[1000];
        static void Main(string[] args)
        {
            //Book[] books = Read("file.csv");

            Console.WriteLine("MOWHAK LIBRARY\n" +
                             "=============================\n");
            Boolean running = true;
            while (running)
            {
                Console.Clear();
                
                Console.WriteLine("MENU\n" +
                                  "1 - List all books \n" +
                                  "2 - List all movies \n" +
                                  "3 - List all songs\n" +
                                  "4 - list all media \n" +
                                  "5 - Search all media by tittle\n" +
                                  "6 - Exit application\n\n" +
                                  "Enter Option: ");
                try
                {
                    choice = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("\nError Incorect Input");


                }
                StreamReader myReader = new StreamReader("Data.txt");
               

                int count = 0;
                




                switch (choice)
                {
                    
                    case 1:
                                                       //spliting the file at | and storying it into a array to see the data types
                        while (!myReader.EndOfStream) //checking to see if the file is not empty
                        {
                            string[] items = myReader.ReadLine().Split('|');
                            if (items[0] == "BOOK")
                            {
                                myBook[count] = new Book(items[1], int.Parse(items[2])); //adding the tital and year
                                myBook[count].Author = items[3];
                                do
                                {
                                    string summary = myReader.ReadLine();

                                    DecryptData decrypt = new DecryptData(summary); //creating a decrtpy 

                                    String decryptedSummary = decrypt.Decrypt();    //sending a decrypt

                                    myBook[count].Summary = decryptedSummary;   //saving the decrypted 

                                } while (myReader.ReadLine() != "-----");   //do while the reader is reading the summary and not the information on the media

                                myMediaList[count] = myBook[count];
                                count++;

                            }
                        }
                        myReader.Close();

                        Array.Resize(ref myMediaList, count);       //resizing the array to remove all empty compentens
                        for (int i = 0; i < myMediaList.Length; i++)
                        {
                            if (choice == 1)
                            {
                                if (myMediaList[i] is Book)
                                {
                                    Console.WriteLine(myMediaList[i].ToString() + "\n");
                                }
                            }
                           
                        }
                        Console.ReadLine();

                        break;
                    case 2:

                        while (!myReader.EndOfStream) //checking to see if the file is not empty
                        {
                            string[] items = myReader.ReadLine().Split('|');
                            if (items[0] == "SONG")
                            {
                                mySong[count] = new song(items[1], int.Parse(items[2]));
                                mySong[count].Album = items[3];
                                mySong[count].Artist = items[4];
                                myMediaList[count] = mySong[count];
                                count++;
                            }
                        }
                        myReader.Close();

                        Array.Resize(ref myMediaList, count);       //resizing the array to remove all empty compentens
                        for (int i = 0; i < myMediaList.Length; i++)
                        {
                            
                          Console.WriteLine(myMediaList[i].ToString() + "\n");

                        }
                        Console.ReadLine();



                        break;
                    case 3:
                        while (!myReader.EndOfStream) //checking to see if the file is not empty
                        {
                            string[] items = myReader.ReadLine().Split('|');
                             if (items[0] == "MOVIE")
                            {
                                myMovie[count] = new movie(items[1], int.Parse(items[2]));
                                myMovie[count].Director = items[3];
                                do
                                {
                                    string summary = myReader.ReadLine();

                                    DecryptData decrypt = new DecryptData(summary);

                                    String decryptedSummary = decrypt.Decrypt();

                                    myMovie[count].Summary = decryptedSummary;

                                } while (myReader.ReadLine() != "-----");
                                myMediaList[count] = myMovie[count];
                                count++;
                            }
                        }
                        myReader.Close();

                        Array.Resize(ref myMediaList, count);       //resizing the array to remove all empty compentens
                        for (int i = 0; i < myMediaList.Length; i++)
                        {

                            Console.WriteLine(myMediaList[i].ToString() + "\n");

                        }
                        Console.ReadLine();

                        break;
                    case 4:
                        while (!myReader.EndOfStream) //checking to see if the file is not empty
                        {
                            string[] items = myReader.ReadLine().Split('|');
                            
                        }
                        myReader.Close();

                        Array.Resize(ref myMediaList, count);       //resizing the array to remove all empty compentens
                        for (int i = 0; i < myMediaList.Length; i++)
                        {

                            Console.WriteLine(myMediaList[i].ToString() + "\n");

                        }
                        Console.ReadLine();
                        break;
                    case 5:
                       // StreamReader myReader = new StreamReader("Data.txt");   //creating a reader for the file 

                        while (!myReader.EndOfStream) //checking to see if the file is not empty
                        {
                            string[] items = myReader.ReadLine().Split('|');    //spliting the file at | and storying it into a array to see the data types
                            if (items[0] == "BOOK")
                            {
                                myBook[count] = new Book(items[1], int.Parse(items[2])); //adding the tital and year
                                myBook[count].Author = items[3];
                                do
                                {
                                    string summary = myReader.ReadLine();

                                    DecryptData decrypt = new DecryptData(summary); //creating a decrtpy 

                                    String decryptedSummary = decrypt.Decrypt();    //sending a decrypt

                                    myBook[count].Summary = decryptedSummary;   //saving the decrypted 

                                } while (myReader.ReadLine() != "-----");   //do while the reader is reading the summary and not the information on the media

                                myMediaList[count] = myBook[count];
                                count++;
                            }
                            /**
                             * Adding the split information into the song array and than adding to the main array same functionality as above
                             */
                            else if (items[0] == "SONG")
                            {
                                mySong[count] = new song(items[1], int.Parse(items[2]));
                                mySong[count].Album = items[3];
                                mySong[count].Artist = items[4];
                                myMediaList[count] = mySong[count];
                                count++;
                            }
                            /**
                             * Adding the split information into the movie array and than adding to the main array same functionality as the BOOK function
                             */
                            else if (items[0] == "MOVIE")
                            {
                                myMovie[count] = new movie(items[1], int.Parse(items[2]));
                                myMovie[count].Director = items[3];
                                do
                                {
                                    string summary = myReader.ReadLine();

                                    DecryptData decrypt = new DecryptData(summary);

                                    String decryptedSummary = decrypt.Decrypt();

                                    myMovie[count].Summary = decryptedSummary;

                                } while (myReader.ReadLine() != "-----");
                                myMediaList[count] = myMovie[count];
                                count++;
                            }
                        }
                        myReader.Close();
                        Array.Resize(ref myMediaList, count);       //resizing the array to remove all empty compentens
                        for (int i = 0; i < myMediaList.Length; i++)
                        {
                            if (choice == 1)
                            {
                                if (myMediaList[i] is Book)
                                {
                                    Console.WriteLine(myMediaList[i].ToString() + "\n");
                                }
                            }
                            else if (choice == 2)
                            {
                                if (myMediaList[i] is movie)
                                {
                                    Console.WriteLine(myMediaList[i].ToString() + "\n");
                                }
                            }
                            else if (choice == 3)
                            {
                                if (myMediaList[i] is song)
                                {
                                    Console.WriteLine(myMediaList[i].ToString() + "\n");
                                }
                            }
                            else if (choice == 4)
                            {

                                Console.WriteLine(myMediaList[i].ToString() + "\n");
                            }
                        }
                        Console.WriteLine("\nEnter a search string: ");
                        String searchString = Console.ReadLine();   //create a searcg string
                        for (int i = 0; i < myMediaList.Length; i++)
                        {
                            if (myMediaList[i].Search(searchString) is true)    //check if the search string returns true
                            {
                                //Print if it is a song, book, or movie, and the summart if needed.
                                if (myMediaList[i] is song)
                                {
                                    Console.WriteLine(myMediaList[i].ToString());
                                }
                                else if (myMediaList[i] is Book)
                                {
                                    Console.WriteLine(myMediaList[i].ToString() + "\n" + myBook[i].Summary + "\n");
                                }
                                else if (myMediaList[i] is movie)
                                {
                                    Console.WriteLine(myMediaList[i].ToString() + "\n" + myMovie[i].Summary + "\n");
                                }

                            }
                            else
                            {
                                Console.WriteLine("Nothing could be found");
                            }
                        }
                        Console.ReadLine();

                        
                        break;

                    case 6:
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid option - please re-enter");
                        break;
                }
                Console.ReadLine();
                
            }
            

        }
        public static void printdata() {
            int count = 100;
            Array.Resize(ref myMediaList, count);       //resizing the array to remove all empty compentens
            for (int i = 0; i < myMediaList.Length; i++)
            {
                if (choice == 1)
                {
                    if (myMediaList[i] is Book)
                    {
                        Console.WriteLine(myMediaList[i].ToString() + "\n");
                    }
                }
                else if (choice == 2)
                {
                    if (myMediaList[i] is movie)
                    {
                        Console.WriteLine(myMediaList[i].ToString() + "\n");
                    }
                }
                else if (choice == 3)
                {
                    if (myMediaList[i] is song)
                    {
                        Console.WriteLine(myMediaList[i].ToString() + "\n");
                    }
                }
                else if (choice == 4)
                {

                    Console.WriteLine(myMediaList[i].ToString() + "\n");
                }
            }


        }


    }
    
}
