﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment03
{
    class song : media
    {
        public string Album { get; set; }
        public string Artist { get; set; }
        public song(string title, int year) : base(title, year)
        {
            String Title = title;
            int Year = year;
        }
        public override String ToString()
        {
            return ("----------------------------\nSong Title: " + Title + " (" + Year) + ")" + "\nAlbum: " + Album + " Artist: " + Artist;
        }
        public new bool Search(string searchString)
        {
            bool searchBool;

            if (Title.Contains(searchString))
            {
                searchBool = true;
            }
            else
            {
                searchBool = false;
            }

            return searchBool;
        }
    }
}
