﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment03
{
    public class Book : media
    {
        public string Author { get; set; }
        public string Summary { get; set; }


        public Book(string title, int year) : base(title, year)
        {
            String Title = title;
            int Year = year;

        }
        public override String ToString()
        {
            return ("----------------------------\nBook Title: " + Title + " (" + Year) + ")" + "\nAuthor: " + Author;
        }
        public new bool Search(string searchString)
        {
            bool searchBool;

            if (Title.Contains(searchString))
            {
                searchBool = true;
            }
            else
            {
                searchBool = false;
            }

            return searchBool;
        }
    }
}