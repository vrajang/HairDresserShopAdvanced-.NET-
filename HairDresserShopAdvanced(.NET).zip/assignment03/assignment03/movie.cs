﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment03
{
    class movie : media
    {

        public string Director { get; set; }
        public string Summary { get; set; }

        public movie(string title, int year) : base(title, year)
        {
            String Title = title;
            int Year = year;
        }
        public override String ToString()
        {
            return ("----------------------------\nMovie Title: " + Title + " (" + Year) + ")" + "\nDirector: " + Director;
        }

        public new bool Search(string searchString)
        {
            bool searchBool;

            if (Title.Contains(searchString))
            {
                searchBool = true;
            }
            else
            {
                searchBool = false;
            }

            return searchBool;
        }
    }
}
