﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
///I, vrajang shah , 000826893  certify that this material is my original work.  No other person's work has been used without due acknowledgement.


namespace assignment3__part2_
{
    public partial class Form1 : Form
    {
        
        
        public Form1()
        {
            InitializeComponent();
            
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {


        }
        
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
           

        }
        private void ComboBox_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (combo.SelectedIndex >= 0)
            {
                listBox2.Items.Add ( combo.SelectedItem.ToString());
                hairdresser h = new hairdresser(combo.SelectedItem.ToString());
                
                listBox3.Items.Add(h.Price(combo.SelectedItem.ToString()));
                
            }
            
            if (listBox1.SelectedIndex >= 0)
            {
                listBox2.Items.Add(listBox1.SelectedItem.ToString());
                services s =new services(listBox1.SelectedItem.ToString());
                
                listBox3.Items.Add(s.priceofserivce(listBox1.SelectedItem.ToString()));
            }
            else
            {
                MessageBox.Show("Plese Select Proper services");
                listBox3.Text = "";
            }

            //combo.ResetText();
            //listBox1.ResetText();
            if (combo.SelectedIndex >= 0)
            {
                combo.Items.Remove(combo.SelectedItem.ToString());
               
            }
            

            
            


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            

        }

        private void button2_Click(object sender, EventArgs e)
        {

            int i = 0, result = 0;
            while (i < listBox3.Items.Count)
            {
                result += Convert.ToInt32(listBox3.Items[i++]);
            }

            textBox1.Text = Convert.ToString("$"+(double)result);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //combo.Items.Add(combo.SelectedItem.ToString());
            combo.ResetText();
            listBox1.ResetText();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            textBox1.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
