﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment3__part2_
{
    class hairdresser
    {
        private int JANE=30;
        private int PAT=45;
        private int RON=40;
        private int Sue = 50;
        private int LAURIE=55;
        private string x;
        public double y;


        public hairdresser(string x) {

            this.x = x;
        }

        public double Price(string x) {

            

            if (x == "JANE ")
            {

                 y = JANE;


            }
            else if (x == "PAT ")
            {
                
                y = PAT;
            }
            else if (x == "RON ") {
                
                y = RON;
            }
            else if (x == "SUE")
            {
                
                y = Sue;
            }
            else 
            {
                
                y = LAURIE;
            }

            return y;

        }


    }
}
