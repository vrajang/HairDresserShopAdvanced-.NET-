﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3__part2_
{
    class services
    {
        private int Cut = 30;
        private int Wash = 20;
        private int Colour = 40;
        private int Highlights = 50;
        private int Extension = 200;
        private int Updo = 60;
        private string p;
        public double q;

        public services(string p) {
            this.p = p;
        
        }

        public double priceofserivce(string p) {
            if (p == "Cut")
            {

                q = Cut;


            }
            else if (p == "Wash, blow-dry, and style")
            {

                q = Wash;
            }
            else if (p == "Color")
            {

                q = Colour;
            }
            else if (p == "Highlights")
            {

                q = Highlights;
            }
            else if (p == "Extension")
            {

                q = Extension;
            }
            else {

                q = Updo;
            }

            return q;


        }
    }
}
